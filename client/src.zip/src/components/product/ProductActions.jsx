import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  FaShoppingCart,
  FaBolt,
  FaHeart,
} from "react-icons/fa";
import { useCart } from "../../context/CartContext";

export default function ProductActions({ product }) {

  const navigate = useNavigate();

  const { addToCart } = useCart();

  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  const handleAddToCart = () => {

    addToCart({
      ...product,
      quantity,
    });

  };

  const handleBuyNow = () => {

    addToCart({
      ...product,
      quantity,
    });

    navigate("/checkout");

  };

  return (

    <div className="mt-10">

      {/* Quantity */}

      <h3 className="text-lg font-semibold">

        Quantity

      </h3>

      <div className="flex items-center gap-4 mt-4">

        <button
          onClick={() =>
            quantity > 1 &&
            setQuantity(quantity - 1)
          }
          className="w-11 h-11 rounded-lg bg-gray-200 text-xl"
        >

          -

        </button>

        <span className="text-xl font-bold">

          {quantity}

        </span>

        <button
          onClick={() =>
            setQuantity(quantity + 1)
          }
          className="w-11 h-11 rounded-lg bg-gray-200 text-xl"
        >

          +

        </button>

      </div>

      {/* Buttons */}

      <div className="grid grid-cols-2 gap-4 mt-8">

        <button

          onClick={handleAddToCart}

          className="

          bg-[#556B2F]

          hover:bg-[#445625]

          text-white

          py-4

          rounded-xl

          font-semibold

          flex

          justify-center

          items-center

          gap-3

          transition

          "

        >

          <FaShoppingCart />

          Add To Cart

        </button>

        <button

          onClick={handleBuyNow}

          className="

          bg-orange-500

          hover:bg-orange-600

          text-white

          py-4

          rounded-xl

          font-semibold

          flex

          justify-center

          items-center

          gap-3

          transition

          "

        >

          <FaBolt />

          Buy Now

        </button>

      </div>

      <button

        className="

        mt-5

        w-full

        border-2

        border-[#556B2F]

        text-[#556B2F]

        hover:bg-[#556B2F]

        hover:text-white

        py-4

        rounded-xl

        font-semibold

        flex

        justify-center

        items-center

        gap-3

        transition

        "

      >

        <FaHeart />

        Add To Wishlist

      </button>

    </div>

  );

}